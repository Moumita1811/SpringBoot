package com.mindtree.shoppingcartapplication.exception;

public class EmptyCartException extends ShoppingCartApplicationException {

	public EmptyCartException(String string) {
		super(string);
	}

}
