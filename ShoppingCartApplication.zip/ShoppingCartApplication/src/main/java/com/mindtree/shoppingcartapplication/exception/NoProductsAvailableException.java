package com.mindtree.shoppingcartapplication.exception;

public class NoProductsAvailableException extends ShoppingCartApplicationException {

	public NoProductsAvailableException(String string) {
		super(string);
	}

}
