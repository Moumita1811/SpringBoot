package com.mindtree.shoppingcartapplication.exception;

public class NoSuchCategoryException extends ShoppingCartApplicationException {

	public NoSuchCategoryException(String string) {
		super(string);
	}

}
