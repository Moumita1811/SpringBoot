package com.mindtree.shoppingcartapplication.exception;

public class NoSuchProductException extends ShoppingCartApplicationException {

	public NoSuchProductException(String string) {
		super(string);
	}

}
