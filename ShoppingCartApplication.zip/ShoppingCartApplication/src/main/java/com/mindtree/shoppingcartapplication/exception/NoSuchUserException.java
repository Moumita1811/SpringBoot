package com.mindtree.shoppingcartapplication.exception;

public class NoSuchUserException extends ShoppingCartApplicationException {

	public NoSuchUserException(String string) {
		super(string);
	}

}
