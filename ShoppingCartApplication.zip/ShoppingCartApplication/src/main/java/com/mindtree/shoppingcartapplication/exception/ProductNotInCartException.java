package com.mindtree.shoppingcartapplication.exception;

public class ProductNotInCartException extends ShoppingCartApplicationException {

	public ProductNotInCartException(String string) {
		super(string);
	}

}
