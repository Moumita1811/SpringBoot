package com.mindtree.shoppingcartapplication.exception;

public class ShoppingCartApplicationException extends Exception{

	public ShoppingCartApplicationException(String string) {
		super(string);
	}

}
